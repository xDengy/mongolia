<?php

IncludeModuleLangFile(__FILE__);

class dolyame_payment extends CModule
{
	const MODULE_ID = 'dolyame.payment';
	public $MODULE_ID = 'dolyame.payment';
	public $MODULE_VERSION;
	public $MODULE_VERSION_DATE;
	public $MODULE_NAME;
	public $MODULE_DESCRIPTION;

	public $strError = '';

	public function __construct()
	{
		$arModuleVersion = array();
		include(dirname(__FILE__) . "/version.php");
		$this->MODULE_VERSION = $arModuleVersion["VERSION"];
		$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		$this->MODULE_NAME = GetMessage("DOLYAME.PAYMENT_MODULE_NAME");
		$this->MODULE_DESCRIPTION = GetMessage("DOLYAME.PAYMENT_MODULE_DESC");
		$this->PARTNER_NAME = GetMessage("DOLYAME.PAYMENT_PARTNER_NAME");
		$this->PARTNER_URI = "https://dolyame.ru/";
	}


	public function InstallFiles()
	{
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/sale_payment/dolyame/", $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/include/sale_payment/dolyame/", true, true);
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/tools/", $_SERVER["DOCUMENT_ROOT"]."/bitrix/tools/");
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/images/dolyame.png", $_SERVER["DOCUMENT_ROOT"]."/bitrix/images/sale/sale_payments/dolyame.png");
		return true;
	}

	public function UnInstallFiles()
	{
		DeleteDirFilesEx("/bitrix/php_interface/include/sale_payment/dolyame");
		DeleteDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".self::MODULE_ID."/install/tools/", $_SERVER["DOCUMENT_ROOT"]."/bitrix/tools/");
		DeleteDirFilesEx("/bitrix/images/sale/sale_payments/dolyame.png");
		return true;
	}

	public function DoInstall()
	{

		$this->InstallFiles();
		RegisterModule(self::MODULE_ID);
		$this->InstallDB();
	}

	public function DoUninstall()
	{
		global $APPLICATION;

		UnRegisterModule(self::MODULE_ID);

		$this->UnInstallFiles();
		$this->UnInstallDB();
	}

	function InstallDB()
	{
		global $DB, $DBType, $APPLICATION;
		$this->errors = false;
		return true;
	}

	function UnInstallDB($arParams = array())
	{
		global $DB, $DBType, $APPLICATION;
		return true;
	}
}


