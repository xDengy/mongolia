<?
require($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/dolyame.payment/payment/dolyame/handler.php");
?>