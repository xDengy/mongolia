<?php

namespace Dolyame\Payment;

class Client
{
	protected $url = 'https://partner.dolyame.ru/v1/orders/';

	protected $login = '';
	protected $password = '';
	protected $certPath = '';
	protected $keyPath = '';
	protected $certPass = '';

	public function __construct(string $login, string $password) {
		$this->login = $login;
		$this->password = $password;
	}

	public function setCertPath(string $certPath)
	{
		$this->certPath = $certPath;
	}

	public function setKeyPath(string $keyPath)
	{
		$this->keyPath = $keyPath;
	}

	public function setCertPass(string $certPass)
	{
		$this->certPass = $certPass;
	}


	public function generateCorrelationId()
	{
		return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
			mt_rand(0, 0xffff), mt_rand(0, 0xffff),
			mt_rand(0, 0xffff),
			mt_rand(0, 0x0fff) | 0x4000,
			mt_rand(0, 0x3fff) | 0x8000,
			mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
		);
	}

	public function create(array $data, string $correlationId = '')
	{
		$data['order']['id'] = $this->prepareOrderId($data['order']['id']);
		return $this->execute('create', $data, 'POST', $correlationId);
	}

	public function cancel(string $orderId, string $correlationId = '')
	{
		$orderId = $this->prepareOrderId($orderId);
		return $this->execute($orderId.'/cancel', [], 'POST', $correlationId);
	}

	public function commit(string $orderId, array $data, string $correlationId = '')
	{
		$orderId = $this->prepareOrderId($orderId);
		return $this->execute($orderId.'/commit', $data, 'POST', $correlationId);
	}

	public function info(string $orderId, string $correlationId = '')
	{
		$orderId = $this->prepareOrderId($orderId);
		return $this->execute($orderId.'/info', [], 'GET', $correlationId);
	}

	public function refund(string $orderId, array $data, string $correlationId = '')
	{
		$orderId = $this->prepareOrderId($orderId);
		return $this->execute($orderId.'/refund', $data, 'POST', $correlationId);
	}

	protected function execute(string $action, array $data, string $method, string $correlationId)
	{
		if($correlationId === '') {
			$correlationId = $this->generateCorrelationId();
		}

		$headers = [
			"Content-Type: application/json",
			"X-Correlation-ID: $correlationId",
			"Authorization: Basic ".base64_encode("{$this->login}:{$this->password}")
		];


		$responseHeaders = '';
		if (!function_exists("curl_init")) {
			throw new \Exception("Curl error");
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->url.$action);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
		curl_setopt($ch, CURLINFO_HEADER_OUT, true);
		curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($curl, $header) use (&$responseHeaders) {
			$responseHeaders .= $header;
			return strlen($header);
		});
		if ($this->certPath) {
			if (!file_exists($this->certPath)) {
				throw new \Exception('Cert path did\'t exist:'.$this->certPath);
			}
			if (!file_exists($this->keyPath)) {
				throw new \Exception('Key path did\'t exist:'.$this->keyPath);
			}
			if (!is_readable($this->certPath)) {
				throw new \Exception('Can\'t read cert file:'.$this->certPath);
			}

			if (!is_readable($this->keyPath)) {
				throw new \Exception('Can\'t read key file:'.$this->keyPath);
			}
			curl_setopt($ch, CURLOPT_SSLCERT, $this->certPath);
			curl_setopt($ch, CURLOPT_SSLKEY, $this->keyPath);
		}
		/*
		if ($this->certPassword) {
			curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $this->certPassword);
		}*/
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		if (!empty($data) || $method == 'POST') {
			$encodedData = json_encode($data, JSON_THROW_ON_ERROR);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
		}

		$out = curl_exec($ch);

		$curlError = curl_error($ch);
		if ($curlError) {
			throw new \Exception($curlError);
		}

		$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$response = json_decode($out, true);
		if ($code == 200) {
			return $response;
		} elseif ($code == 429) {
			$headers = $this->parseHeadersToArray($responseHeaders);
			sleep($headers['X-Retry-After']);
			return $this->execute($action, $data, $method, $correlationId);
		}

		$error = 'Error: ' . $code;

		if (isset($response['type']) && $response['type'] == 'error') {
			$error .= ' ' . $response['description'];
		}
		if (isset($response['message'])) {
			$error .= ' '.$response['message'];
		}
		if (!empty($response['details'])) {
			$list = array_map(
				function($key, $value){return "$key - $value";},
				array_keys($response['details']),
				array_values($response['details'])
			);
			$error .= ': '.implode($list);;
		}

		if (!$response) {
			$error .= $out;
		}
		throw new \Exception($error, $code);
	}

	protected function parseHeadersToArray(string $rawHeaders)
	{
		$lines = explode("\r\n", $rawHeaders);
		$headers = [];
		foreach($lines as $line) {
			if (strpos($line, ':') === false ){
				continue;
			}
			list($key, $value) = explode(': ', $line);
			$headers[$key] = $value;
		}
		return $headers;
	}

	protected function prepareOrderId(string $orderId){
		$orderId = str_replace(['/','#','?','|',' '], ['-'], $orderId);
		return $orderId;
	}

}
