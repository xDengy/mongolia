<?
$dolyame_payment_default_option = array(
    "redirect_exclude_list"                => "/personal/orders/",
    );
?>