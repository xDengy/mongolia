<?php
$arClasses = array(
  'Dolyame\Payment\Client'      => 'lib/Client.php',
);

CModule::AddAutoloadClasses("dolyame.payment", $arClasses);

?>