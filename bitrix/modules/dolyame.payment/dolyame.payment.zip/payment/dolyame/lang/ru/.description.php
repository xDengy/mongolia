<?
$MESS["DOLYAME.PAYMENT_PAYMENT_TITLE"] = "Долями - оплата покупок частями";
$MESS["DOLYAME.PAYMENT_OPTIONS_ORDER_NUMBER"] = "Номер заказа";
$MESS["DOLYAME.PAYMENT_OPTIONS_SHOP_NAME"] = "Логин";
$MESS["DOLYAME.PAYMENT_OPTIONS_SHOP_PASSWORD"] = "Пароль";
$MESS["DOLYAME.PAYMENT_OPTIONS_CERT_PATH"] = "Путь на сервере до сертификата MTLS";
$MESS["DOLYAME.PAYMENT_OPTIONS_CERT_PATH_DESC"] = "Относительно папки сайта (напр.: ../open-api-cert.pem)";
$MESS["DOLYAME.PAYMENT_OPTIONS_KEY_PATH"] = "Путь путь до приватного ключа";
$MESS["DOLYAME.PAYMENT_OPTIONS_KEY_PATH_DESC"] = "Относительно папки сайта (напр.: ../private.key)";
$MESS["DOLYAME.PAYMENT_OPTIONS_CERT_PASS"] = "Пароль от сертификата";
$MESS["DOLYAME.PAYMENT_OPTIONS_CERT_PASS_DESC"] = "Если он был указан при генерации ключа";
$MESS["DOLYAME.PAYMENT_OPTIONS_SUCCESS_URL"] = "Адрес страницы возврата после в случае успешной оплаты";
$MESS["DOLYAME.PAYMENT_OPTIONS_SUCCESS_URL_DESC"] = "";
$MESS["DOLYAME.PAYMENT_OPTIONS_FAIL_URL"] = "Адрес страницы возврата в случае неудачи";
$MESS["DOLYAME.PAYMENT_OPTIONS_FAIL_URL_DESC"] = "";
$MESS["DOLYAME.PAYMENT_OPTIONS_AUTO_REDIRECT"] = "Автопереход к оплате";
$MESS["DOLYAME.PAYMENT_OPTIONS_AUTO_REDIRECT_DESC"] = "После оформления заказа покупатель будет сразу перенаправлен на страницу оплаты, без промежуточной страницы. Исключения настраиваются в настройках модуля";


