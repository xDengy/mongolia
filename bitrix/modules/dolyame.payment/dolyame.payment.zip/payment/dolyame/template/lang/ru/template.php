<?
$MESS["DOLYAME.PAYMENT_DESCRIPTION"] = "Сумма к оплате по счету: ";
$MESS["DOLYAME.PAYMENT_REDIRECT"] = "вы будете перенаправленны на страницу оплаты";
$MESS["DOLYAME.PAYMENT_BUTTON_PAID"] = "Оплатить";
$MESS["DOLYAME.PAYMENT_REDIRECT_MESS"] = "Вы будете перенаправленны на страницу оплаты";