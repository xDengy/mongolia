<?php
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__);

$sum = round($params['amount'], 2);
?>

<div class="mb-4" >
	<p><?=Loc::getMessage('DOLYAME.PAYMENT_DESCRIPTION')." ".SaleFormatCurrency($sum, 'RUB');?></p>
	<div class="d-flex align-items-center mb-3">
		<div class="col-auto pl-0">
			<a class="btn btn-lg btn-success" style="border-radius: 32px;" href="<?=$params['link'];?>"><?=Loc::getMessage('DOLYAME.PAYMENT_BUTTON_PAID')?></a>
		</div>
		<div class="col pr-0"><?=Loc::getMessage('DOLYAME.PAYMENT_REDIRECT_MESS');?></div>
	</div>

	<p><?=Loc::getMessage('DOLYAME.PAYMENT_WARNING_RETURN');?></p>
</div>