<?php

namespace Sale\Handlers\PaySystem;

use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\Localization;
use Bitrix\Main\Request;
use Bitrix\Sale\Order;
use Bitrix\Sale\Payment;
use Bitrix\Sale\PaySystem;
use Bitrix\Sale\PriceMaths;
use Bitrix\Main\Config\Option;
use Dolyame\Payment\Client;


\CModule::IncludeModule("dolyame.payment");

class DolyameHandler extends PaySystem\ServiceHandler implements PaySystem\IRefund
{
	/**
	 * @param Payment $payment
	 * @param Request|null $request
	 * @return PaySystem\ServiceResult
	 */
	public function initiatePay(Payment $payment, Request $request = null)
	{
		$result           = new PaySystem\ServiceResult();
		$paymentShouldPay = number_format(PriceMaths::roundPrecision($payment->getSum()), 2, '.', '');
		$order            = $payment->getCollection()->getOrder();

		$data = [
			'order' => [
				'id'               => $this->getBusinessValue($payment, 'ORDER_NUMBER'),
				'amount'           => $paymentShouldPay,
				'prepaid_amount'   => 0,
				'items'            => $this->getOrderItems($payment),
			],
			'client_info'      => [
					'first_name' => $this->getFirstName($order),
					'last_name'  => $this->getLastName($order),
					'phone'      => $this->getPhone($order),
					'email'      => $this->getEmail($order),
			],
			'notification_url' => $this->getNotifyUrl($payment),
			'fail_url'         => $this->getBusinessValue($payment, 'FAIL_URL'),
			'success_url'      => $this->getBusinessValue($payment, 'SUCCESS_URL'),
		];

		$createResult = $this->createPayment($data);
		if (!$createResult->isSuccess()) {
			$result->addErrors($createResult->getErrors());
			return $result;
		}

		$paymentData = $createResult->getData();
		$result->setPaymentUrl($paymentData['link']);
		if ($this->needRedirect() ) {
			LocalRedirect($paymentData['link'], true);
		}

		$this->setExtraParams($paymentData);

		$showTemplateResult = $this->showTemplate($payment, "template");
		if ($showTemplateResult->isSuccess()) {
			$result->setTemplate($showTemplateResult->getTemplate());
		} else {
			$result->addErrors($showTemplateResult->getErrors());
		}



		return $result;
	}

	protected function needRedirect()
	{
		if ($this->getBusinessValue($payment, 'AUTO_REDIRECT') != 'Y') {
			return false;
		}

		$url = $this->service->getContext()->getUrl();
		$path = parse_url($url, PHP_URL_PATH);
		$exclideList = Option::get('dolyame.payment', 'redirect_exclude_list');
		$exclideList = explode("\n", $exclideList);
		foreach($exclideList as $url) {
			if (strpos($path, $url) !== false) {
				return false;
			}
		}
		return true;
	}

	public function getCurrencyList()
	{
		return ['RUB'];
	}

	public function refund(Payment $payment, $refundableSum)
	{
		$result = new PaySystem\ServiceResult();

		$data = [
			'amount'                  => $refundableSum,
			'returned_items'          => $this->getOrderItems($payment),
			'refunded_prepaid_amount' => 0,
		];
		$refundResult = $this->createRefund($payment, $data);

		if (!$refundResult->isSuccess()) {
			$result->addErrors($refundResult->getErrors());
			return $result;
		}

		$response = $refundResult->getData();

		if (PriceMaths::roundPrecision($response->amount) === PriceMaths::roundPrecision($refundableSum)) {
			$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);
		}

		return $result;
	}


	public static function isMyResponse(Request $request, $paySystemId)
	{
		return $request->get('BX_PAYSYSTEM_CODE') === $paySystemId;
	}

	public function getPaymentIdFromRequest(Request $request)
	{
		return $request->get('BX_PAYMENT_ID');
	}

	public function processRequest(Payment $payment, Request $request)
	{
		$result          = new PaySystem\ServiceResult();
		$orderInfoResult = $this->getOrderInfo($payment);
		if (!$orderInfoResult->isSuccess()) {
			$result->addErrors($orderInfoResult->getErrors());
			return $result;
		}
		$orderInfo = $orderInfoResult->getData();
		if ($orderInfo['status'] === 'waiting_for_commit') {
			$commitResult = $this->commitPayment($payment);
			if (!$commitResult->isSuccess()) {
				$result->addErrors($commitResult->getErrors());
				return $result;
			}
		}

		if ($orderInfo['status'] === 'committed') {
			$description = Localization\Loc::getMessage('DOLYAME.PAYMENT_TRANSACTION') . $orderInfo['id'];
			$fields      = array(
				'PS_INVOICE_ID'         => $orderInfo['id'],
				"PS_STATUS_CODE"        => mb_substr($orderInfo['status'], 0, 5),
				"PS_STATUS_DESCRIPTION" => $description,
				"PS_SUM"                => $orderInfo['amount'],
				"PS_STATUS"             => 'Y',
				"PS_RESPONSE_DATE"      => new Main\Type\DateTime(),
			);

			PaySystem\Logger::addDebugInfo(
				__CLASS__ . ': PS_CHANGE_STATUS_PAY=' . $this->getBusinessValue($payment, 'PS_CHANGE_STATUS_PAY')
			);

			$result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);

			$result->setPsData($fields);
		}
		return $result;
	}

	public function sendResponse(PaySystem\ServiceResult $result, Request $request)
	{
		global $APPLICATION;
		if (!$result->isSuccess()) {
			$APPLICATION->RestartBuffer();
			header("HTTP/1.1 500 " . $result->getErrorMessages()[0]);
		}
		return '';
	}

	protected function getOrderItems(Payment $payment)
	{
		$items              = [];
		$shipmentCollection = $payment
			->getCollection()
			->getOrder()
			->getShipmentCollection();

		foreach ($shipmentCollection as $shipment) {
			$shipmentItemCollection = $shipment->getShipmentItemCollection();

			foreach ($shipmentItemCollection as $shipmentItem) {
				$basketItem = $shipmentItem->getBasketItem();
				if ($basketItem->isBundleChild()) {
					continue;
				}

				if (!$basketItem->getFinalPrice()) {
					continue;
				}

				if ($shipmentItem->getQuantity() <= 0) {
					continue;
				}
				$itemPrice = $basketItem->getPrice();
				if (method_exists($basketItem, "getPriceWithVat")) {
					$itemPrice = $basketItem->getPriceWithVat();
				}
				$item = [
					"name"     => $basketItem->getField('NAME'),
					"quantity" => $shipmentItem->getQuantity(),
					"price"    => number_format(PriceMaths::roundPrecision($itemPrice), 2, '.', ''),
				];
				$items[] = $item;

			}
			if (!$shipment->isSystem() && $shipment->getPrice()) {
				$items[] = array(
					"name"     => $shipment->getDeliveryName(),
					"quantity" => 1,
					"price"    => number_format(PriceMaths::roundPrecision($shipment->getPrice()), 2, '.', ''),
				);
			}
		}
		return $items;
	}

	protected function getNotifyUrl(Payment $payment)
	{
		$request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
		$params  = [
			'BX_PAYSYSTEM_CODE' => $payment->getPaymentSystemId(),
			'BX_PAYMENT_ID'     => $payment->getId(),
		];
		$url = 'https://' . $request->getHttpHost() . '/bitrix/tools/sale_ps_result.php?' . http_build_query($params);
		return $url;
	}

	protected function createPayment($data)
	{
		$result = new PaySystem\ServiceResult();

		$login    = $this->getBusinessValue($payment, 'SHOP_NAME');
		$password = $this->getBusinessValue($payment, 'SHOP_PASSWORD');

		$api = new Client($login, $password);
		$api->setCertPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'CERT_PATH'));
		$api->setKeyPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'KEY_PATH'));
		if ($this->getBusinessValue($payment, 'CERT_PASS')) {
			$api->setCertPass($this->getBusinessValue($payment, 'CERT_PASS'));
		}
		try {
			$response = $api->create($data);
			$result->setData($response);
		} catch (\Exception $e) {
			$result->addError(new Error($e->getMessage()));
		}
		return $result;
	}

	protected function createRefund($payment, $data)
	{
		$result = new PaySystem\ServiceResult();

		$login       = $this->getBusinessValue($payment, 'SHOP_NAME');
		$password    = $this->getBusinessValue($payment, 'SHOP_PASSWORD');
		$orderNumber = $this->getBusinessValue($payment, 'ORDER_NUMBER');

		$api = new Client($login, $password);
		$api->setCertPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'CERT_PATH'));
		$api->setKeyPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'KEY_PATH'));
		if ($this->getBusinessValue($payment, 'CERT_PASS')) {
			$api->setCertPass($this->getBusinessValue($payment, 'CERT_PASS'));
		}
		try {
			$response = $api->refund($orderNumber, $data);
			$result->setData($response);
		} catch (\Exception $e) {
			$result->addError(new Error($e->getMessage()));
		}
		return $result;
	}

	protected function getOrderInfo(Payment $payment)
	{
		$result   = new PaySystem\ServiceResult();
		$login    = $this->getBusinessValue($payment, 'SHOP_NAME');
		$password = $this->getBusinessValue($payment, 'SHOP_PASSWORD');

		$api = new Client($login, $password);
		$api->setCertPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'CERT_PATH'));
		$api->setKeyPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'KEY_PATH'));
		if ($this->getBusinessValue($payment, 'CERT_PASS')) {
			$api->setCertPass($this->getBusinessValue($payment, 'CERT_PASS'));
		}
		try {
			$response = $api->info($this->getBusinessValue($payment, 'ORDER_NUMBER'));
			$result->setData($response);
		} catch (\Exception $e) {
			$result->addError(new Error('Order info error: ' . $e->getMessage()));
		}
		return $result;
	}

	protected function commitPayment(Payment $payment)
	{
		$result   = new PaySystem\ServiceResult();
		$login    = $this->getBusinessValue($payment, 'SHOP_NAME');
		$password = $this->getBusinessValue($payment, 'SHOP_PASSWORD');


		$api              = new Client($login, $password);
		$api->setCertPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'CERT_PATH'));
		$api->setKeyPath($_SERVER["DOCUMENT_ROOT"].'/'.$this->getBusinessValue($payment, 'KEY_PATH'));
		if ($this->getBusinessValue($payment, 'CERT_PASS')) {
			$api->setCertPass($this->getBusinessValue($payment, 'CERT_PASS'));
		}
		$paymentShouldPay = number_format(PriceMaths::roundPrecision($payment->getSum()), 2, '.', '');
		$data             = [
			'amount'         => $paymentShouldPay,
			'items'          => $this->getOrderItems($payment),
			'prepaid_amount' => 0,
		];

		try {
			$response = $api->commit($this->getBusinessValue($payment, 'ORDER_NUMBER'), $data);
			$result->setData($response);
		} catch (\Exception $e) {
			$result->addError(new Error('Commit error: ' . $e->getMessage()));
		}
		return $result;
	}

	protected function getPhone(Order $order)
	{
		$phone = '';
		try {
			if ($propUserPhone = $order->getPropertyCollection()->getPhone()) {
				$phone = $propUserPhone->getValue();
			}
		} catch (\Exception $e) {
			return '';
		}

		$phone = preg_replace("#[^\d]#", "", $phone);
		if (!preg_match("#[7|8]{0,1}(\d{10})#", $phone, $match)) {
			return '';
		}
		return '+7' . $match[1];
	}

	protected function getFirstName(Order $order)
	{
		$name = '';
		try {
			if ($prop = $order->getPropertyCollection()->getPayerName()) {
				$name = $prop->getValue();
			}
		} catch (\Exception $e) {
			return '';
		}
		$name = explode(' ', $name)[0];
		return $name;
	}

	protected function getLastName(Order $order)
	{
		$name = '';
		try {
			if ($prop = $order->getPropertyCollection()->getPayerName()) {
				$name = $prop->getValue();
			}
		} catch (\Exception $e) {
			return '';
		}
		$name = explode(' ', $name);
		if (count($name) < 2) {
			return '';
		}
		return $name[1];
	}

	protected function getEmail(Order $order)
	{
		$email = '';
		try {
			if ($prop = $order->getPropertyCollection()->getUserEmail()) {
				$email = $prop->getValue();
			}
		} catch (\Exception $e) {
			return '';
		}
		return $email;
	}

}
