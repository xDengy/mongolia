<?
global $MESS;
$MESS ['DOLYAME.PAYMENT_PARTNER_NAME'] = "Долями";
$MESS ['DOLYAME.PAYMENT_MODULE_NAME'] = "Долями – модуль приема платежей";
$MESS ['DOLYAME.PAYMENT_MODULE_DESC'] = "Модуль позволяет принимать в вашем магазине оплату Долями при помощи банковских карт, Apple Pay и Google Pay";
?>