<?
global $MESS;
$MESS ['DOLYAME.PAYMENT_REDIRECT_LIMIT'] = "Список страниц, с которых не нужно автоматически перенаправлять на оплату";
$MESS ['DOLYAME.PAYMENT_REDIRECT_LIMIT_DESC'] = "Каждая с новой строки";

?>